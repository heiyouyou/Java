package com.seven;

public class Test {
	public static void main(String args[]){
		Person person = new Person();
		person.name = "麻子";
		person.age = 18;
		person.sex = '男';
		person.show();
	}
}
